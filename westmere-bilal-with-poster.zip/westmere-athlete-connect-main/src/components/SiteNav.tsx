import { Link } from "@tanstack/react-router";

export function SiteNav() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/60 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-3">
          <span className="grid size-9 place-items-center bg-turf font-display text-lg leading-none text-turf-foreground">
            W
          </span>
          <span className="font-display text-lg tracking-wide">
            WESTMERE <span className="text-muted-foreground">STRATEGY</span>
          </span>
        </Link>
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <Link to="/" className="transition-colors hover:text-foreground">
            Home
          </Link>
          <a href="/#capabilities" className="transition-colors hover:text-foreground">
            Capabilities
          </a>
          <a href="/#work" className="transition-colors hover:text-foreground">
            Work
          </a>
          <Link to="/ceo" className="transition-colors hover:text-foreground">
            The CEO
          </Link>
        </nav>
        <a
          href="/#inquiry"
          className="rounded-full bg-turf px-5 py-2 text-sm font-semibold text-turf-foreground transition-colors hover:bg-foreground"
        >
          Start a conversation
        </a>
      </div>
    </header>
  );
}
