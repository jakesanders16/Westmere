const ITEMS = ["Athlete Marketing", "Brand Strategy", "Campaigns", "Partnerships", "Market Growth", "Community Activations"];

export function LeagueMarquee() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <section
      aria-label="Westmere services and areas of focus"
      className="border-y border-border/70 bg-surface/40 py-5"
    >
      <div className="flex overflow-hidden">
        <div className="animate-marquee flex shrink-0 items-center gap-12 pr-12 font-display text-2xl uppercase tracking-wide text-foreground/70">
          {row.map((item, i) => (
            <span key={i} className="flex items-center gap-12">
              <span>{item}</span>
              <span className="text-turf">/</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
