import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="relative z-10 border-t border-border/70 bg-surface/40">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-6 py-10 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-3">
          <span className="grid size-8 place-items-center bg-turf font-display text-turf-foreground">
            W
          </span>
          <span className="font-display tracking-wide">WESTMERE STRATEGY GROUP</span>
        </div>
        <div className="flex gap-8 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
          <Link to="/" className="transition-colors hover:text-foreground">
            Home
          </Link>
          <a href="/#capabilities" className="transition-colors hover:text-foreground">
            Capabilities
          </a>
          <a href="/#work" className="transition-colors hover:text-foreground">
            Work
          </a>
          <Link to="/ceo" className="transition-colors hover:text-foreground">
            The CEO
          </Link>
        </div>
        <div className="flex flex-col gap-2 md:items-end">
          <a href="mailto:westmerestrategy@gmail.com" className="font-mono text-xs tracking-wide text-muted-foreground transition-colors hover:text-foreground">westmerestrategy@gmail.com</a>
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            © 2026 Westmere Strategy Group
          </p>
        </div>
      </div>
    </footer>
  );
}
