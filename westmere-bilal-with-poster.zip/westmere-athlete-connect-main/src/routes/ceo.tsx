import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";
import { LeagueMarquee } from "@/components/LeagueMarquee";
import founderPhoto from "@/assets/founder-jake.png";

export const Route = createFileRoute("/ceo")({
  head: () => ({
    meta: [
      { title: "Jake Sanders | Founder & CEO , Westmere Strategy Group" },
      {
        name: "description",
        content:
          "Meet Jake Sanders, founder of Westmere Strategy Group, connecting athletes and brands through thoughtful partnerships and promotional opportunities.",
      },
      { property: "og:title", content: "Jake Sanders | Westmere Strategy Group" },
      {
        property: "og:description",
        content: "Athlete relationships, brand partnerships, and opportunities built to last.",
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CeoPage,
});

function CeoPage() {
  return (
    <div className="min-h-screen bg-background font-body text-foreground antialiased">
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[5] overflow-hidden">
        <div className="absolute -left-[35%] top-[8%] flex -rotate-[24deg] flex-col gap-28 whitespace-nowrap opacity-[0.035]">
          {Array.from({ length: 8 }, (_, i) => (
            <p key={i} className="font-display text-[clamp(4rem,10vw,9rem)] font-bold uppercase tracking-[0.12em]">
              WESTMERE　WESTMERE　WESTMERE
            </p>
          ))}
        </div>
      </div>
      <div className="pointer-events-none fixed inset-0 z-0 bg-[radial-gradient(ellipse_at_50%_0%,rgba(119,145,166,0.10),transparent_52%)]" />
      <SiteNav />
      <main className="relative z-10">
        <section className="mx-auto max-w-7xl px-6 pb-20 pt-16 md:pb-24 md:pt-24">
          <div className="grid items-center gap-12 md:grid-cols-12 md:gap-16">
            <div className="md:col-span-7">
              <p className="animate-rise font-mono text-[11px] uppercase tracking-[0.32em] text-turf" style={{ animationDelay: "60ms" }}>
                Founder &amp; CEO
              </p>
              <h1 className="animate-rise mt-6 max-w-[11ch] font-display text-[clamp(3.4rem,8vw,7.4rem)] leading-[0.88] tracking-[-0.045em]" style={{ animationDelay: "150ms" }}>
                Jake <span className="text-turf">Sanders.</span>
              </h1>
              <p className="animate-rise mt-8 max-w-[54ch] text-base leading-8 text-muted-foreground md:text-lg" style={{ animationDelay: "260ms" }}>
                I work across athlete marketing and brand growth, helping people and organizations clarify their story, reach the right audiences, and act on new opportunities.
              </p>
              <div className="animate-rise mt-9 flex flex-wrap items-center gap-4" style={{ animationDelay: "360ms" }}>
                <a href="/#inquiry" className="inline-flex items-center gap-3 border border-turf/70 bg-turf px-6 py-3 text-xs font-semibold uppercase tracking-[0.18em] text-turf-foreground transition hover:bg-transparent hover:text-turf">
                  Let’s connect <span aria-hidden="true">↗</span>
                </a>
                <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Westmere Strategy Group</span>
              </div>
            </div>
            <div className="animate-rise md:col-span-5" style={{ animationDelay: "220ms" }}>
              <div className="relative mx-auto max-w-[460px]">
                <div className="absolute -inset-3 border border-border/70" />
                <img src={founderPhoto} alt="Jake Sanders, Founder and CEO of Westmere Strategy Group" className="relative aspect-[4/5] w-full object-cover object-center grayscale-[12%]" />
                <div className="absolute -bottom-5 -left-5 bg-surface px-5 py-4 shadow-xl">
                  <p className="font-mono text-[9px] uppercase tracking-[0.25em] text-muted-foreground">Founder / CEO</p>
                  <p className="mt-1 font-display text-lg tracking-wide">Jake Sanders</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-y border-border/80 bg-surface/60">
          <div className="mx-auto grid max-w-7xl gap-12 px-6 py-16 md:grid-cols-12 md:py-20">
            <div className="md:col-span-5">
              <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-turf">01 / The perspective</p>
              <h2 className="mt-5 max-w-[12ch] font-display text-4xl leading-[1.02] tracking-tight md:text-5xl">Built on trust. Focused on opportunity.</h2>
            </div>
            <div className="md:col-span-7 md:pt-8">
              <p className="max-w-[62ch] text-sm leading-7 text-muted-foreground md:text-base">
                My background in sales and sports marketing taught me that strong work starts with listening and follow-through. At the club level, I’ve helped secure more than $30,000 in sponsorship deals, developed promotional concepts, and helped bring athletes and local organizations together.
              </p>
              <p className="mt-5 max-w-[62ch] text-sm leading-7 text-muted-foreground md:text-base">
                Westmere works on both sides of growth: helping athletes develop their image, marketing, and career direction, while helping brands and organizations expand through strategy, partnerships, campaigns, and activations. The work is tailored to each client’s goals, not a one-size-fits-all playbook.
              </p>
            </div>
          </div>
        </section>



        <section className="border-y border-border/80 bg-surface/50">
          <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px bg-border/60 md:grid-cols-4">
            {[
              ["$30K+", "Partnership deals secured"],
              ["Two-sided", "Support for brands and talent"],
              ["Strategy + action", "From planning to activation"],
              ["Built to grow", "Reach, reputation, opportunity"],
            ].map(([stat, label]) => (
              <div key={label} className="bg-background/95 px-6 py-8 md:px-8 md:py-10">
                <p className="font-display text-3xl text-turf md:text-4xl">{stat}</p>
                <p className="mt-3 max-w-[18ch] font-mono text-[9px] uppercase leading-5 tracking-[0.17em] text-muted-foreground">{label}</p>
              </div>
            ))}
          </div>
        </section>


        <LeagueMarquee />
      </main>
      <SiteFooter />
    </div>
  );
}
