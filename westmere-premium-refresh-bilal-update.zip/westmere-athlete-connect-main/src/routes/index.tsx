import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { SiteNav } from "@/components/SiteNav";
import { SiteFooter } from "@/components/SiteFooter";
import { LeagueMarquee } from "@/components/LeagueMarquee";
import dougPhoto from "@/assets/doug-edert.jpg";
import jetsPhoto from "@/assets/jets-connection.jpg";
import mmaPhoto from "@/assets/mma-connection.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Westmere Strategy Group | Athletes x Brands" },
      {
        name: "description",
        content:
          "Brand growth and athlete marketing, built around clear strategy and real execution.",
      },
      { property: "og:title", content: "Westmere Strategy Group | Athletes x Brands" },
      {
        property: "og:description",
        content:
          "Helping brands grow their reach and athletes build stronger personal brands.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const CASES = [
  { num: "01", tag: "College basketball", title: "Doug Edert", body: "A relationship with March Madness standout Doug Edert, reflecting Westmere’s work across athlete visibility and brand conversations.", img: dougPhoto, alt: "Jake with Doug Edert", pos: "center" },
  { num: "02", tag: "Professional football", title: "New York Jets", body: "Helped connect New York Jets players with local organizations for community-facing opportunities.", img: jetsPhoto, alt: "Jake with a New York Jets player", pos: "center" },
  { num: "03", tag: "Mixed martial arts", title: "Phumi Nkuta (9-1)", body: "A community event appearance that brought a professional athlete and local fans together.", img: mmaPhoto, alt: "Jake with an MMA athlete", pos: "center" },
];

function Index() {
  const [inquiryStatus, setInquiryStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  return (
    <div className="min-h-screen bg-background font-body text-foreground antialiased">
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[5] overflow-hidden">
        <div className="absolute -left-[35%] top-[8%] flex -rotate-[24deg] flex-col gap-28 whitespace-nowrap opacity-[0.035]">
          {Array.from({ length: 8 }, (_, i) => (
            <p key={i} className="font-display text-[clamp(4rem,10vw,9rem)] font-bold uppercase tracking-[0.12em]">
              WESTMERE　WESTMERE　WESTMERE
            </p>
          ))}
        </div>
      </div>
      {/* ambient light */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="animate-glow absolute -top-40 left-1/2 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-turf/10 blur-[120px]" />
        <div className="absolute right-0 bottom-0 h-[420px] w-[520px] rounded-full bg-turf/5 blur-[120px]" />
      </div>

      <SiteNav />

      <main className="relative z-10">
        {/* HERO */}
        <section className="mx-auto max-w-7xl px-6 pt-14 pb-10 md:pt-20 md:pb-12">
          <p
            className="animate-rise mb-5 font-mono text-[11px] uppercase tracking-[0.28em] text-turf"
            style={{ animationDelay: "60ms" }}
          >
            Athletes and brands. One desk.
          </p>
          <h1 className="max-w-[1200px] font-display text-[clamp(1.75rem,4.3vw,3.75rem)] leading-[1.02] tracking-tight uppercase">
            <span className="block">Make your <span className="text-turf">next move.</span></span>
            <span className="block">Build lasting <span className="text-turf">momentum.</span></span>
          </h1>
          <div className="mt-7 flex flex-col gap-5 md:mt-8 md:flex-row md:items-end md:justify-between">
            <p
              className="max-w-[52ch] text-sm leading-6 text-muted-foreground md:text-base"
              style={{ animationDelay: "240ms" }}
            >
              Brand growth and athlete marketing, built around clear strategy and real execution.
            </p>
            <div className="flex shrink-0 flex-wrap gap-3">
              <a
                href="#inquiry"
                className="rounded-full bg-turf px-6 py-3 text-sm font-semibold text-turf-foreground transition-colors hover:bg-foreground"
              >
                Start a conversation
              </a>
              <a
                href="#work"
                className="rounded-full border border-border px-6 py-3 text-sm font-semibold transition-colors hover:bg-surface"
              >
                See the work
              </a>
            </div>
          </div>
          <div className="animate-rule mt-9 h-px w-full bg-border" style={{ animationDelay: "500ms" }} />
        </section>

        {/* LEAGUE MARQUEE */}
        <LeagueMarquee />

        {/* CAPABILITIES: ATHLETES + BRANDS */}
        <section id="capabilities" className="mx-auto max-w-7xl px-6 py-24">
          <div className="grid gap-12 md:grid-cols-12">
            <div className="md:col-span-3">
              <p className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">
                (a) Two sides, one desk
              </p>
              <div className="animate-rule mt-4 h-px w-16 bg-turf" />

            </div>
            <div className="grid gap-6 md:col-span-9 md:grid-cols-2">
              <div className="animate-rise rounded-2xl border border-border/70 bg-surface/60 p-8" style={{ animationDelay: "120ms" }}>
                <p className="font-mono text-xs uppercase tracking-[0.25em] text-turf">For athletes</p>
                <h3 className="mt-4 font-display text-3xl leading-tight uppercase">
                  Build your image
                </h3>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">
                  Shape your image, sharpen your message, and grow your audience.
                </p>
              </div>
              <div className="animate-rise rounded-2xl border border-border/70 bg-surface/60 p-8" style={{ animationDelay: "220ms" }}>
                <p className="font-mono text-xs uppercase tracking-[0.25em] text-turf">For brands</p>
                <h3 className="mt-4 font-display text-3xl leading-tight uppercase">
                  Reach new markets
                </h3>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">
                  Reach new markets and customers through thoughtful campaigns and partnerships.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* HOW WE WORK */}
        <section className="mx-auto max-w-7xl px-6 pb-20">
          <div className="border-t border-border/70 pt-8">
            <div className="grid gap-8 md:grid-cols-12 md:items-end">
              <div className="md:col-span-4">
                <p className="font-mono text-xs uppercase tracking-[0.3em] text-turf">A clear path forward</p>
                <h2 className="mt-3 font-display text-4xl leading-tight tracking-tight uppercase md:text-5xl">From idea to impact.</h2>
              </div>
              <div className="grid gap-5 sm:grid-cols-3 md:col-span-8">
                {[
                  ["01", "Listen", "Start with your goals, audience, and opportunity."],
                  ["02", "Shape", "Build the positioning, plan, and right connections."],
                  ["03", "Activate", "Put the plan into motion and learn from the response."],
                ].map(([num, title, body]) => (
                  <div key={num} className="border-l border-turf/60 pl-4">
                    <p className="font-mono text-[10px] tracking-[0.2em] text-turf">{num}</p>
                    <h3 className="mt-2 font-display text-2xl uppercase">{title}</h3>
                    <p className="mt-2 text-sm leading-6 text-muted-foreground">{body}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CASE STUDIES */}
        <section id="work" className="mx-auto max-w-7xl px-6 pb-24">
          <div className="flex items-end justify-between">
            <div>
              <p className="font-mono text-xs uppercase tracking-[0.3em] text-muted-foreground">
                (b) Selected work
              </p>
              <h2 className="mt-3 font-display text-5xl tracking-tight uppercase">
                Experience across people, brands, and communities
              </h2>
            </div>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {CASES.map((c, i) => (
              <article
                key={c.num}
                className="animate-rise group overflow-hidden rounded-2xl border border-border/70 bg-surface/60 transition-colors hover:border-turf/50"
                style={{ animationDelay: `${120 + i * 100}ms` }}
              >
                <div className="overflow-hidden">
                  <img
                    src={c.img}
                    alt={c.alt}
                    loading="lazy"
                    style={{ objectPosition: c.pos }}
                    className="aspect-[16/10] w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    <span className="font-display text-4xl text-turf/90">{c.num}</span>
                    <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      {c.tag}
                    </span>
                  </div>
                  <h3 className="mt-4 font-display text-2xl leading-tight uppercase">{c.title}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{c.body}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* FEATURED PERFORMANCE: BILAL HASAN */}
        <section className="mx-auto max-w-7xl px-6 pb-24">
          <div className="relative overflow-hidden rounded-3xl border border-turf/30 bg-surface/70">
            <div aria-hidden="true" className="pointer-events-none absolute -right-24 -top-28 h-80 w-80 rounded-full bg-turf/10 blur-[90px]" />
            <div className="relative grid gap-10 p-8 md:grid-cols-12 md:items-center md:p-12">
              <div className="md:col-span-5">
                <p className="font-mono text-[10px] uppercase tracking-[0.28em] text-turf">Featured appearance · Social performance</p>
                <h2 className="mt-4 font-display text-4xl leading-[1.02] tracking-tight uppercase md:text-5xl">Bilal Hasan<br /><span className="text-turf">Appearance</span></h2>
                <p className="mt-5 max-w-[44ch] text-sm leading-7 text-muted-foreground">
                  An athlete appearance that turned fan engagement into meaningful social reach for the venue.
                </p>
                <p className="mt-6 font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Westmere Strategy Group · Campaign results</p>
              </div>
              <div className="grid gap-px overflow-hidden rounded-2xl border border-border/70 bg-border/70 sm:grid-cols-2 md:col-span-7">
                <div className="bg-background/90 p-7 md:p-8">
                  <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">Total views</p>
                  <p className="mt-3 font-display text-6xl tracking-tight text-turf md:text-7xl">500K</p>
                  <p className="mt-2 text-sm text-muted-foreground">Views generated</p>
                </div>
                <div className="bg-background/90 p-7 md:p-8">
                  <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">Likes</p>
                  <p className="mt-3 font-display text-6xl tracking-tight md:text-7xl">10K</p>
                  <p className="mt-2 text-sm text-muted-foreground">Audience engagement</p>
                </div>
                <div className="bg-background/90 p-7 sm:col-span-2 md:p-8">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                      <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">Venue reach benchmark</p>
                      <p className="mt-3 font-display text-5xl tracking-tight text-turf md:text-6xl">50×+</p>
                    </div>
                    <p className="max-w-[32ch] text-sm leading-6 text-muted-foreground sm:text-right">
                      More than 50 times the views of a typical venue Instagram post.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* STAT BAND */}
        <section className="border-y border-border/70 bg-surface/40">
          <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px bg-border/50 md:grid-cols-4">
            {[
              ["$30K+", "Club-level sponsorship deals supported"],
              ["Two-sided", "Support for brands and talent"],
              ["Strategy + action", "From planning to activation"],
              ["Built to grow", "Reach, reputation, opportunity"],
            ].map(([stat, label]) => (
              <div key={label} className="bg-surface/70 p-8">
                <p className="font-display text-5xl text-turf">{stat}</p>
                <p className="mt-2 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                  {label}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* INQUIRY FORM */}
        <section id="inquiry" className="mx-auto max-w-7xl scroll-mt-24 px-6 py-24">
          <div className="grid gap-12 border border-border/80 bg-surface/60 p-8 md:grid-cols-12 md:p-14">
            <div className="md:col-span-5">
              <p className="font-mono text-xs uppercase tracking-[0.3em] text-turf">Start a conversation</p>
              <h2 className="mt-5 max-w-[12ch] font-display text-5xl leading-[0.95] tracking-tight md:text-6xl">What are you looking to build?</h2>
              <p className="mt-6 max-w-[42ch] text-sm leading-7 text-muted-foreground">A few details are all we need to start a useful conversation.</p>
            </div>
            <form className="grid gap-5 md:col-span-7" onSubmit={async (event) => {
              event.preventDefault();
              const form = event.currentTarget;
              setInquiryStatus("sending");
              const data = new FormData(form);
              data.append("_subject", `New Westmere website inquiry: ${String(data.get("inquiryType") || "General")}`);
              data.append("_template", "table");
              try {
                const response = await fetch("https://formsubmit.co/ajax/westmerestrategy@gmail.com", {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json",
                  },
                  body: JSON.stringify(Object.fromEntries(data.entries())),
                });
                const result = await response.json();
                if (!response.ok || result.success === "false" || result.success === false) {
                  throw new Error(result.message || "Could not send inquiry");
                }
                setInquiryStatus("success");
                form.reset();
              } catch {
                setInquiryStatus("error");
              }
            }}>
              <div className="grid gap-5 sm:grid-cols-2">
                <label className="grid gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Name
                  <input required name="name" autoComplete="name" className="min-h-12 border border-border bg-background px-4 font-body text-sm normal-case tracking-normal text-foreground outline-none focus:border-turf" placeholder="Your name" />
                </label>
                <label className="grid gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Email
                  <input required type="email" name="email" autoComplete="email" className="min-h-12 border border-border bg-background px-4 font-body text-sm normal-case tracking-normal text-foreground outline-none focus:border-turf" placeholder="you@example.com" />
                </label>
                <label className="grid gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Phone number (optional)
                  <input type="tel" name="phone" autoComplete="tel" className="min-h-12 border border-border bg-background px-4 font-body text-sm normal-case tracking-normal text-foreground outline-none focus:border-turf" placeholder="(555) 555-5555" />
                </label>
              </div>
              <label className="grid gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">I’m reaching out as
                <select name="inquiryType" className="min-h-12 border border-border bg-background px-4 font-body text-sm normal-case tracking-normal text-foreground outline-none focus:border-turf">
                  <option>Athlete</option><option>Brand or business</option><option>Organization or community</option><option>Other</option>
                </select>
              </label>
              <label className="grid gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">How can we help?
                <textarea required name="message" rows={5} className="resize-y border border-border bg-background px-4 py-3 font-body text-sm normal-case tracking-normal text-foreground outline-none focus:border-turf" placeholder="Tell us a little about the opportunity or goal..." />
              </label>
              <div className="flex flex-wrap items-center gap-4">
                <button type="submit" className="inline-flex items-center gap-3 bg-turf px-7 py-3.5 text-sm font-semibold text-turf-foreground transition hover:opacity-85">Send inquiry <span aria-hidden="true">↗</span></button>
                <span className="text-xs text-muted-foreground">Your message will be sent directly to our inbox.</span>
              </div>
              {inquiryStatus === "sending" && <p role="status" className="text-sm text-muted-foreground">Sending your inquiry…</p>}
              {inquiryStatus === "success" && <p role="status" className="border border-turf/40 bg-background p-4 text-sm">Thanks for reaching out. Your inquiry has been sent.</p>}
              {inquiryStatus === "error" && <p role="alert" className="border border-destructive/40 bg-background p-4 text-sm">We couldn’t send your inquiry. Please email westmerestrategy@gmail.com directly.</p>}
            </form>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
